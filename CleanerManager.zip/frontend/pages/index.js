export default function Home() {
    return <h1>Cleaner Manager Dashboard</h1>;
}
